<form class="contact-form" action="contacted.php" method="post">
	<h2 class="title">Email Us Today For The Best Price</h2>
	<input class="textbox" type="text" name="name" placeholder="Name">
	<input class="textbox" type="text" name="email" placeholder="Email">
	<textarea class="message" type="textarea" name="message" placeholder="Message" rows="5"></textarea>
	<input type="submit" value="Submit">
</form>